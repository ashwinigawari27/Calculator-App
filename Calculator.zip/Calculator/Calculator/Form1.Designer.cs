﻿namespace Calculator
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button2 = new Button();
            button4 = new Button();
            button8 = new Button();
            button3 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button20 = new Button();
            txtOutput = new TextBox();
            button1 = new Button();
            SuspendLayout();
            // 
            // button2
            // 
            button2.BackColor = SystemColors.AppWorkspace;
            button2.Font = new Font("Segoe UI", 14.25F);
            button2.Location = new Point(72, 70);
            button2.Name = "button2";
            button2.Size = new Size(48, 43);
            button2.TabIndex = 1;
            button2.Text = "CE";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button_clearEntery_click;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.AppWorkspace;
            button4.Font = new Font("Segoe UI", 14.25F);
            button4.Location = new Point(171, 70);
            button4.Name = "button4";
            button4.Size = new Size(45, 43);
            button4.TabIndex = 3;
            button4.Text = "/";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button_Click;
            // 
            // button8
            // 
            button8.BackColor = SystemColors.AppWorkspace;
            button8.Font = new Font("Segoe UI", 14.25F);
            button8.Location = new Point(121, 70);
            button8.Name = "button8";
            button8.Size = new Size(49, 43);
            button8.TabIndex = 7;
            button8.Text = "%";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button_Click;
            // 
            // 
            // button3
            // 
            button3.BackColor = SystemColors.AppWorkspace;
            button3.Font = new Font("Segoe UI", 14.25F);
            button3.Location = new Point(122, 114);
            button3.Name = "button3";
            button3.Size = new Size(49, 43);
            button3.TabIndex = 11;
            button3.Text = "9";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button_Click;
            // 
            // 
            // button5
            // 
            button5.BackColor = SystemColors.AppWorkspace;
            button5.Font = new Font("Segoe UI", 14.25F);
            button5.Location = new Point(172, 114);
            button5.Name = "button5";
            button5.Size = new Size(45, 43);
            button5.TabIndex = 10;
            button5.Text = "*";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button_Click;
            // 
            // button6
            // 
            button6.BackColor = SystemColors.AppWorkspace;
            button6.Font = new Font("Segoe UI", 14.25F);
            button6.Location = new Point(73, 114);
            button6.Name = "button6";
            button6.Size = new Size(48, 43);
            button6.TabIndex = 9;
            button6.Text = "8";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button_Click;
            // 
            // button7
            // 
            button7.BackColor = SystemColors.AppWorkspace;
            button7.Font = new Font("Segoe UI", 14.25F);
            button7.Location = new Point(23, 114);
            button7.Name = "button7";
            button7.Size = new Size(49, 43);
            button7.TabIndex = 8;
            button7.Text = "7";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button_Click;
            // 
            // button9
            // 
            button9.BackColor = SystemColors.AppWorkspace;
            button9.Font = new Font("Segoe UI", 14.25F);
            button9.Location = new Point(121, 159);
            button9.Name = "button9";
            button9.Size = new Size(49, 43);
            button9.TabIndex = 19;
            button9.Text = "6";
            button9.UseVisualStyleBackColor = false;
            button9.Click += button_Click;
            // 
            // button10
            // 
            button10.BackColor = SystemColors.AppWorkspace;
            button10.Font = new Font("Segoe UI", 14.25F);
            button10.Location = new Point(171, 159);
            button10.Name = "button10";
            button10.Size = new Size(45, 43);
            button10.TabIndex = 18;
            button10.Text = "-";
            button10.UseVisualStyleBackColor = false;
            button10.Click += button_Click;
            // 
            // button11
            // 
            button11.BackColor = SystemColors.AppWorkspace;
            button11.Font = new Font("Segoe UI", 14.25F);
            button11.Location = new Point(72, 159);
            button11.Name = "button11";
            button11.Size = new Size(48, 43);
            button11.TabIndex = 17;
            button11.Text = "5";
            button11.UseVisualStyleBackColor = false;
            button11.Click += button_Click;
            // 
            // button12
            // 
            button12.BackColor = SystemColors.AppWorkspace;
            button12.Font = new Font("Segoe UI", 14.25F);
            button12.Location = new Point(22, 159);
            button12.Name = "button12";
            button12.Size = new Size(49, 43);
            button12.TabIndex = 16;
            button12.Text = "4";
            button12.UseVisualStyleBackColor = false;
            button12.Click += button_Click;
            // 
            // button13
            // 
            button13.BackColor = SystemColors.AppWorkspace;
            button13.Font = new Font("Segoe UI", 14.25F);
            button13.Location = new Point(121, 204);
            button13.Name = "button13";
            button13.Size = new Size(49, 43);
            button13.TabIndex = 23;
            button13.Text = "3";
            button13.UseVisualStyleBackColor = false;
            button13.Click += button_Click;
            // 
            // button14
            // 
            button14.BackColor = SystemColors.AppWorkspace;
            button14.Font = new Font("Segoe UI", 14.25F);
            button14.Location = new Point(171, 204);
            button14.Name = "button14";
            button14.Size = new Size(45, 43);
            button14.TabIndex = 22;
            button14.Text = "+";
            button14.UseVisualStyleBackColor = false;
            button14.Click += button_Click;
            // 
            // button15
            // 
            button15.BackColor = SystemColors.AppWorkspace;
            button15.Font = new Font("Segoe UI", 14.25F);
            button15.Location = new Point(72, 204);
            button15.Name = "button15";
            button15.Size = new Size(48, 43);
            button15.TabIndex = 21;
            button15.Text = "2";
            button15.UseVisualStyleBackColor = false;
            button15.Click += button_Click;
            // 
            // button16
            // 
            button16.BackColor = SystemColors.AppWorkspace;
            button16.Font = new Font("Segoe UI", 14.25F);
            button16.Location = new Point(22, 204);
            button16.Name = "button16";
            button16.Size = new Size(49, 43);
            button16.TabIndex = 20;
            button16.Text = "1";
            button16.UseVisualStyleBackColor = false;
            button16.Click += button_Click;
            // 
            // button17
            // 
            button17.BackColor = SystemColors.AppWorkspace;
            button17.Font = new Font("Segoe UI", 14.25F);
            button17.Location = new Point(121, 249);
            button17.Name = "button17";
            button17.Size = new Size(49, 43);
            button17.TabIndex = 27;
            button17.Text = ".";
            button17.UseVisualStyleBackColor = false;
            button17.Click += button_Click;
            // 
            // button18
            // 
            button18.BackColor = SystemColors.AppWorkspace;
            button18.Font = new Font("Segoe UI", 14.25F);
            button18.Location = new Point(171, 249);
            button18.Name = "button18";
            button18.Size = new Size(45, 43);
            button18.TabIndex = 26;
            button18.Text = "=";
            button18.UseVisualStyleBackColor = false;
            button18.Click += button_Equals_Click;
            // 
            // button20
            // 
            button20.BackColor = SystemColors.AppWorkspace;
            button20.Font = new Font("Segoe UI", 14.25F);
            button20.Location = new Point(22, 249);
            button20.Name = "button20";
            button20.Size = new Size(98, 43);
            button20.TabIndex = 24;
            button20.Text = "0";
            button20.UseVisualStyleBackColor = false;
            button20.Click += button_Click;
            // 
            // txtOutput
            // 
            txtOutput.Location = new Point(24, 27);
            txtOutput.Name = "txtOutput";
            txtOutput.Size = new Size(196, 23);
            txtOutput.TabIndex = 28;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.AppWorkspace;
            button1.Font = new Font("Segoe UI", 14.25F);
            button1.Location = new Point(25, 70);
            button1.Name = "button1";
            button1.Size = new Size(47, 43);
            button1.TabIndex = 0;
            button1.Text = "C";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button_Clear_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(242, 334);
            Controls.Add(txtOutput);
            Controls.Add(button17);
            Controls.Add(button18);
            Controls.Add(button20);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button16);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button3);
            Controls.Add(button5);
            Controls.Add(button6);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button4);
            Controls.Add(button2);
            Controls.Add(button1);
            Name = "Form1";
            Text = "Calculator";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button2;
        private Button button4;
        private Button button8;
        private Button button3;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button20;
        private TextBox txtOutput;
        private Button button1;
    }
}
